const urlInput = document.getElementById("videoUrl");
const downloadBtn = document.getElementById("downloadBtn");
const clearBtn = document.getElementById("clearBtn");
const fileInput = document.getElementById("fileInput");
const statusBox = document.getElementById("status");
const themeBtn = document.getElementById("themeBtn");

function showStatus(message) {
  statusBox.textContent = message;
  statusBox.classList.remove("hidden");
}

clearBtn.addEventListener("click", () => {
  urlInput.value = "";
  statusBox.classList.add("hidden");
  urlInput.focus();
});

downloadBtn.addEventListener("click", async () => {
  const raw = urlInput.value.trim();

  if (!raw) {
    showStatus("Please paste a direct video-file URL first.");
    return;
  }

  let url;
  try {
    url = new URL(raw);
  } catch {
    showStatus("That doesn't look like a valid URL.");
    return;
  }

  if (!["http:", "https:"].includes(url.protocol)) {
    showStatus("Please use an HTTP or HTTPS video URL.");
    return;
  }

  showStatus(
    "This UI accepts direct video-file URLs. Your hosting/backend must provide the actual authorized file and appropriate CORS permissions."
  );

  // For a same-origin/direct file URL, you can enable the following
  // download behavior:
  //
  // const a = document.createElement("a");
  // a.href = url.href;
  // a.download = "video";
  // document.body.appendChild(a);
  // a.click();
  // a.remove();
});

fileInput.addEventListener("change", () => {
  const file = fileInput.files[0];
  if (!file) return;

  const objectUrl = URL.createObjectURL(file);
  const a = document.createElement("a");
  a.href = objectUrl;
  a.download = file.name || "video";
  document.body.appendChild(a);
  a.click();
  a.remove();

  setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  showStatus(`Ready: ${file.name}`);
});

const savedTheme = localStorage.getItem("reeldrop-theme");
if (savedTheme) document.documentElement.dataset.theme = savedTheme;

themeBtn.addEventListener("click", () => {
  const dark = document.documentElement.dataset.theme === "dark";
  const next = dark ? "light" : "dark";
  document.documentElement.dataset.theme = next;
  localStorage.setItem("reeldrop-theme", next);
  themeBtn.textContent = dark ? "☾" : "☀";
});
